import React from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { 
  FaHome,
  FaUsers,
  FaSchool,
  FaHeadset,
  FaChartBar,
  FaCog,
  FaChevronRight,
  FaChevronLeft,
  FaUserTie,
  FaExclamationTriangle,
  FaTicketAlt,
  FaFileAlt,
  FaLink
} from 'react-icons/fa';

const Sidebar = ({ isOpen, onToggle }) => {
  const location = useLocation();

  const menuItems = [
    { 
      id: 'overview', 
      label: 'نظرة عامة', 
      icon: FaHome, 
      path: '/dashboard/admin' 
    },
    { 
      id: 'users', 
      label: 'المستخدمين', 
      icon: FaUsers, 
      path: '/dashboard/admin/users' 
    },
    { 
      id: 'schools', 
      label: 'المدارس', 
      icon: FaSchool, 
      path: '/dashboard/admin/schools' 
    },
    { 
      id: 'supervisor-links', 
      label: 'دعوات المشرفين', 
      icon: FaUserTie, 
      path: '/dashboard/admin/supervisor-links' 
    },
    { 
      id: 'complaints', 
      label: 'الشكاوى', 
      icon: FaExclamationTriangle, 
      path: '/dashboard/admin/complaints' 
    },
    { 
      id: 'support', 
      label: 'الدعم الفني', 
      icon: FaHeadset, 
      path: '/dashboard/admin/support' 
    },
    { 
      id: 'reports', 
      label: 'التقارير', 
      icon: FaFileAlt, 
      path: '/dashboard/admin/reports' 
    },
    { 
      id: 'settings', 
      label: 'الإعدادات', 
      icon: FaCog, 
      path: '/dashboard/admin/settings' 
    }
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <motion.aside
        className={`hidden lg:block fixed right-0 top-16 h-[calc(100vh-4rem)] bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 shadow-lg z-40 transition-all duration-300 ${
          isOpen ? 'w-64' : 'w-20'
        }`}
        initial={false}
        animate={{ width: isOpen ? 256 : 80 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
      >
        <div className="flex flex-col h-full">
          {/* Menu Items */}
          <nav className="flex-1 py-4 overflow-y-auto">
            <ul className="space-y-1 px-2">
              {menuItems.map((item) => {
                const isActive = location.pathname === item.path || 
                                (item.path !== '/dashboard/admin' && location.pathname.startsWith(item.path));
                const Icon = item.icon;
                
                return (
                  <li key={item.id}>
                    <Link
                      to={item.path}
                      className={`flex items-center w-full p-3 rounded-lg transition-all duration-200 group ${
                        isActive 
                          ? 'bg-primary-500 text-white shadow-md' 
                          : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                      }`}
                    >
                      <div className={`flex items-center justify-center w-8 h-8 ${
                        isActive ? 'text-white' : 'text-gray-500 dark:text-gray-400 group-hover:text-primary-500'
                      }`}>
                        <Icon className="text-lg" />
                      </div>
                      
                      <motion.span
                        className="mr-3 font-medium whitespace-nowrap overflow-hidden"
                        animate={{ 
                          opacity: isOpen ? 1 : 0,
                          width: isOpen ? 'auto' : 0
                        }}
                        transition={{ duration: 0.2 }}
                      >
                        {item.label}
                      </motion.span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
          
          {/* Toggle Button */}
          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            <button
              onClick={onToggle}
              className="flex items-center justify-center w-full p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            >
              {isOpen ? (
                <FaChevronRight className="text-lg" />
              ) : (
                <FaChevronLeft className="text-lg" />
              )}
            </button>
          </div>
        </div>
      </motion.aside>

      {/* Mobile Sidebar */}
      <motion.aside
        className={`lg:hidden fixed right-0 top-16 h-[calc(100vh-4rem)] bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 shadow-lg z-40 ${
          isOpen ? 'w-64' : 'w-0'
        } transition-all duration-300 overflow-hidden`}
        initial={false}
        animate={{ width: isOpen ? 256 : 0 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
      >
        <div className="flex flex-col h-full">
          {/* Menu Items */}
          <nav className="flex-1 py-4 overflow-y-auto">
            <ul className="space-y-1 px-2">
              {menuItems.map((item) => {
                const isActive = location.pathname === item.path || 
                                (item.path !== '/dashboard/admin' && location.pathname.startsWith(item.path));
                const Icon = item.icon;
                
                return (
                  <li key={item.id}>
                    <Link
                      to={item.path}
                      className={`flex items-center w-full p-3 rounded-lg transition-all duration-200 group ${
                        isActive 
                          ? 'bg-primary-500 text-white shadow-md' 
                          : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                      }`}
                      onClick={() => onToggle()} // Close sidebar on mobile after navigation
                    >
                      <div className={`flex items-center justify-center w-8 h-8 ${
                        isActive ? 'text-white' : 'text-gray-500 dark:text-gray-400 group-hover:text-primary-500'
                      }`}>
                        <Icon className="text-lg" />
                      </div>
                      
                      <span className="mr-3 font-medium whitespace-nowrap">
                        {item.label}
                      </span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>
      </motion.aside>
    </>
  );
};

export default Sidebar;