import React, { useState, useContext } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../../../../contexts/AuthContext';
import { 
  FaBell, 
  FaUser, 
  FaSignOutAlt, 
  FaCog, 
  FaBars,
  FaMoon,
  FaSun
} from 'react-icons/fa';
import { useNotifications } from '../../hooks/useAdminData';

const AdminHeader = ({ onMenuClick }) => {
  const navigate = useNavigate();
  const { logout, user } = useContext(AuthContext);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 shadow-sm sticky top-0 z-50">
      <div className="flex items-center justify-between px-4 py-3">
        {/* Left side - Menu button and title */}
        <div className="flex items-center">
          <button
            onClick={onMenuClick}
            className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 mr-2 lg:hidden"
          >
            <FaBars className="text-xl" />
          </button>
          
          <h1 className="text-xl font-bold text-gray-900 dark:text-white hidden md:block">
            لوحة تحكم المدير
          </h1>
        </div>

        {/* Right side - Actions */}
        <div className="flex items-center space-x-4 space-x-reverse">
          {/* Theme Toggle */}
          <button className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700">
            <FaMoon className="text-xl hidden dark:block" />
            <FaSun className="text-xl block dark:hidden" />
          </button>

          {/* Notifications */}
          <div className="relative">
            <button 
              className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 relative"
              onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
            >
              <FaBell className="text-xl" />
              <span className="absolute top-1 left-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            
            {/* Notifications Dropdown */}
            {isNotificationsOpen && (
              <div className="absolute left-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 z-50">
                <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                  <h3 className="font-bold text-gray-900 dark:text-white">الإشعارات</h3>
                </div>
                <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                  لا توجد إشعارات جديدة
                </div>
              </div>
            )}
          </div>

          {/* Profile */}
          <div className="relative">
            <button 
              className="flex items-center space-x-2 space-x-reverse p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              onClick={() => setIsProfileOpen(!isProfileOpen)}
            >
              <div className="w-8 h-8 rounded-full bg-primary-500 flex items-center justify-center text-white font-semibold">
                {user?.name?.charAt(0) || 'م'}
              </div>
            </button>
            
            {/* Profile Dropdown */}
            {isProfileOpen && (
              <motion.div 
                className="absolute left-0 mt-2 w-64 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 z-50"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
              >
                <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                  <div className="flex items-center space-x-3 space-x-reverse">
                    <div className="w-12 h-12 rounded-full bg-primary-500 flex items-center justify-center text-white font-semibold text-lg">
                      {user?.name?.charAt(0) || 'م'}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">{user?.name || 'مدير النظام'}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">مدير النظام</p>
                    </div>
                  </div>
                </div>
                
                <div className="py-2">
                  <button 
                    className="w-full flex items-center space-x-3 space-x-reverse px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-right"
                    onClick={() => {
                      setIsProfileOpen(false);
                      // Navigate to profile
                    }}
                  >
                    <FaUser className="text-gray-400" />
                    <span className="text-gray-700 dark:text-gray-300">الملف الشخصي</span>
                  </button>
                  
                  <button 
                    className="w-full flex items-center space-x-3 space-x-reverse px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-right"
                    onClick={() => {
                      setIsProfileOpen(false);
                      // Navigate to settings
                    }}
                  >
                    <FaCog className="text-gray-400" />
                    <span className="text-gray-700 dark:text-gray-300">الإعدادات</span>
                  </button>
                </div>
                
                <div className="border-t border-gray-200 dark:border-gray-700 py-2">
                  <button 
                    className="w-full flex items-center space-x-3 space-x-reverse px-4 py-3 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors text-right"
                    onClick={() => {
                      setIsProfileOpen(false);
                      handleLogout();
                    }}
                  >
                    <FaSignOutAlt className="text-red-400" />
                    <span className="text-red-600 dark:text-red-400">تسجيل الخروج</span>
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default AdminHeader;