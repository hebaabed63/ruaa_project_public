import { useState, useEffect } from 'react';

// Mock data for admin dashboard
const mockStats = {
  totalUsers: 124,
  activeUsers: 98,
  schools: 24,
  supportTickets: 5,
  totalLinks: 18,
  activeLinks: 12,
  pendingUsers: 26,
  pendingNotifications: 3
};

// Mock recent activities
const mockRecentActivities = [
  {
    id: 1,
    title: 'مستخدم جديد مسجل',
    description: 'تم تسجيل مستخدم جديد في النظام',
    timestamp: new Date().toISOString(),
    type: 'user'
  },
  {
    id: 2,
    title: 'مدرسة جديدة مضافة',
    description: 'تمت إضافة مدرسة جديدة إلى النظام',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    type: 'school'
  },
  {
    id: 3,
    title: 'طلب دعم جديد',
    description: 'تم استلام طلب دعم فني جديد',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    type: 'support'
  }
];

export const useDashboardStats = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true);
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // In a real application, this would be an API call:
        // const response = await fetch('/api/admin/dashboard-stats');
        // const data = await response.json();
        
        setStats(mockStats);
        setError(null);
      } catch (err) {
        setError('Failed to fetch dashboard statistics');
        console.error('Error fetching stats:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  return { stats, loading, error };
};

export const useRecentActivities = () => {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        setLoading(true);
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // In a real application, this would be an API call:
        // const response = await fetch('/api/admin/recent-activities');
        // const data = await response.json();
        
        setActivities(mockRecentActivities);
      } catch (err) {
        console.error('Error fetching activities:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchActivities();
  }, []);

  return { activities, loading };
};

export const useNotifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    // Mock notifications data
    const mockNotifications = [
      {
        id: 1,
        title: 'مستخدم جديد بحاجة للموافقة',
        message: 'هناك مستخدم جديد يحتاج إلى موافقة الإدارة',
        timestamp: new Date().toISOString(),
        read: false,
        actionUrl: '/dashboard/admin/users'
      },
      {
        id: 2,
        title: 'طلب دعم فني',
        message: 'تم استلام طلب دعم فني جديد',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        read: false,
        actionUrl: '/dashboard/admin/support'
      }
    ];

    setNotifications(mockNotifications);
    setUnreadCount(mockNotifications.filter(n => !n.read).length);
  }, []);

  const markAsRead = (id) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
    setUnreadCount(prev => prev - 1);
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    );
    setUnreadCount(0);
  };

  return { notifications, unreadCount, markAsRead, markAllAsRead };
};

export const useUISettings = () => {
  const [settings, setSettings] = useState({
    theme: 'light',
    sidebarCollapsed: false,
    compactMode: false
  });

  const toggleTheme = () => {
    setSettings(prev => ({
      ...prev,
      theme: prev.theme === 'light' ? 'dark' : 'light'
    }));
  };

  const toggleSidebar = () => {
    setSettings(prev => ({
      ...prev,
      sidebarCollapsed: !prev.sidebarCollapsed
    }));
  };

  const toggleCompactMode = () => {
    setSettings(prev => ({
      ...prev,
      compactMode: !prev.compactMode
    }));
  };

  return { settings, toggleTheme, toggleSidebar, toggleCompactMode };
};