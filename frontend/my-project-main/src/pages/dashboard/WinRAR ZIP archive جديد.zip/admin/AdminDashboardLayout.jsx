import React from 'react';
import { Routes, Route } from 'react-router-dom';

import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import UsersManagementPage from './pages/UsersManagementPage';
import SchoolsManagementPage from './pages/SchoolsManagementPage';
import SupervisorLinksManagementPage from './pages/SupervisorLinksManagementPage';
import ComplaintsManagementPage from './pages/ComplaintsManagementPage';
import SupportTicketsManagementPage from './pages/SupportTicketsManagementPage';
import ReportsManagementPage from './pages/ReportsManagementPage';
import SettingsManagementPage from './pages/SettingsManagementPage';

const AdminDashboardLayout = () => {
  return (
    <Layout>
      <Routes>
        <Route index element={<Dashboard />} />
        <Route path="/" element={<Dashboard />} />
        <Route path="/users" element={<UsersManagementPage />} />
        <Route path="/schools" element={<SchoolsManagementPage />} />
        <Route path="/supervisor-links" element={<SupervisorLinksManagementPage />} />
        <Route path="/complaints" element={<ComplaintsManagementPage />} />
        <Route path="/support" element={<SupportTicketsManagementPage />} />
        <Route path="/reports" element={<ReportsManagementPage />} />
        <Route path="/settings" element={<SettingsManagementPage />} />

        {/* Default route to dashboard */}
        <Route path="*" element={<Dashboard />} />
      </Routes>
    </Layout>
  );
};

export default AdminDashboardLayout;