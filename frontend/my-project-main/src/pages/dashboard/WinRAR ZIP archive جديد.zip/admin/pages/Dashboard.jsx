import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { 
  FaSchool,
  FaUsers, 
  FaChartLine,
  FaComments,
  FaBell,
  FaCalendarAlt,
  FaFileAlt,
  FaUserTie,
  FaExclamationTriangle,
  FaHeadset,
  FaLink
} from 'react-icons/fa';

import { Card, Loading, Button } from '../components/ui';
import { useDashboardStats } from '../hooks/useAdminData';

// ======= StatsCard Component =======
const StatsCard = ({ title, value, icon: Icon, color, loading = false, suffix, index }) => {
  const colorClasses = {
    primary: 'text-primary-500',
    success: 'text-green-500', 
    warning: 'text-purple-500',
    danger: 'text-cyan-500',
    info: 'text-black-500'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ 
        duration: 0.6, 
        ease: "easeOut",
        delay: index * 0.1 
      }}
      whileHover={{ 
        y: -10,
        scale: 1.03,
        transition: { duration: 0.3 }
      }}
    >
      <Card className="relative overflow-hidden h-full group bg-[#F9F9FA] dark:bg-gray-700 transition-colors">
        <div className="absolute inset-0 bg-slate-200 dark:bg-gray-600 opacity-30 group-hover:opacity-70 transition-opacity" />
        <div className="relative z-10 flex flex-col h-full justify-between">
          <div className="flex justify-end mb-2">
            <div className={`${colorClasses[color]}`}>
              <Icon className="text-2xl" />
            </div>
          </div>
          <div className="space-y-1 mt-auto text-center">
            <p
              className="text-lg text-gray-900 dark:text-white font-bold truncate overflow-hidden whitespace-nowrap"
              title={title}
            >
              {title}
            </p>
            <h3
              className="text-sm font-thin text-gray-500 dark:text-gray-300 truncate overflow-hidden whitespace-nowrap"
              title={value}
            >
              {loading ? <Loading type="spinner" size="sm" /> : `${value} ${suffix || ''}`}
            </h3>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

// ======= AdminDashboard Page =======
const Dashboard = () => {
  const navigate = useNavigate();
  const { stats, loading: statsLoading } = useDashboardStats();

  const quickActions = [
    { label: 'إدارة المستخدمين', icon: FaUsers, color: 'text-[#64C8CC]', action: () => navigate('/dashboard/admin/users'), description: 'إدارة جميع المستخدمين في النظام' },
    { label: 'إدارة المدارس', icon: FaSchool, color: 'text-[#30A1DB]', action: () => navigate('/dashboard/admin/schools'), description: 'إدارة المدارس والمديرين' },
    { label: 'دعوات المشرفين', icon: FaUserTie, color: 'text-[#1CB654]', action: () => navigate('/dashboard/admin/supervisor-links'), description: 'إدارة دعوات المشرفين' },
    { label: 'الشكاوى', icon: FaExclamationTriangle, color: 'text-[#9F45F2]', action: () => navigate('/dashboard/admin/complaints'), description: 'عرض الشكاوى والإشعارات' }
  ];

  return (
    <div className="container mx-auto bg-white dark:bg-gray-900 p-4 transition-colors" dir="rtl">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ 
          duration: 0.8, 
          ease: "easeOut" 
        }}
        className="mb-8"
      >
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">
          أهلا بك في لوحة تحكم المدير!
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          هذه لوحة التحكّم الخاصة بك لإدارة النظام بالكامل.
        </p>
      </motion.div>

      {/* Top Stats Cards */}
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        initial="hidden"
        animate="visible"
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: {
              staggerChildren: 0.2
            }
          }
        }}
      >
        <StatsCard title="إجمالي المستخدمين" value={statsLoading ? '...' : stats?.totalUsers || 0} suffix="مستخدم" icon={FaUsers} color="danger" loading={statsLoading} index={0} />
        <StatsCard title="المدارس" value={statsLoading ? '...' : stats?.schools || 0} suffix="مدرسة" icon={FaSchool} color="warning" loading={statsLoading} index={1} />
        <StatsCard title="الدعم الفني" value={statsLoading ? '...' : stats?.supportTickets || 0} suffix="طلب" icon={FaHeadset} color="success" loading={statsLoading} index={2} />
        <StatsCard title="الإشعارات الجديدة" value={statsLoading ? '...' : stats?.pendingNotifications || 0} suffix="إشعار" icon={FaBell} color="info" loading={statsLoading} index={3} />
      </motion.div>

      {/* Charts Section */}
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut", delay: 0.4 }}
      >
        <motion.div
          className="bg-[#F9F9FA] dark:bg-gray-700 p-4 rounded-xl col-span-1"
          whileHover={{ 
            y: -5,
            transition: { duration: 0.3 }
          }}
        >
          <div className="border border-[#E5E7E9] dark:border-gray-600 rounded-xl p-4 bg-[#F9F9FA] dark:bg-gray-700">
            <motion.h3 
              className="text-gray-700 dark:text-gray-200 font-bold mb-4 text-right"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              نظرة عامة على النظام
            </motion.h3>
            <div className="border border-gray-300 dark:border-gray-600 rounded-xl p-4 bg-[#F9F9FA] dark:bg-gray-700">
              <div className="flex justify-between items-center p-3 rounded-md mb-6 bg-gray-50 dark:bg-gray-600">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 bg-[#64C8CC] rounded-sm"></div>
                  <span className="text-gray-700 dark:text-gray-200 font-semibold">إحصائيات النظام</span>
                </div>
              </div>
              <div className="text-center py-8">
                <FaChartLine className="text-4xl text-[#64C8CC] mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-300">سيتم عرض الرسوم البيانية هنا</p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          className="bg-[#F9F9FA] dark:bg-gray-700 p-4 rounded-xl col-span-1"
          whileHover={{ 
            y: -5,
            transition: { duration: 0.3 }
          }}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.5 }}
        >
          <div className="border border-[#E5E7E9] dark:border-gray-600 rounded-xl p-4 bg-[#F9F9FA] dark:bg-gray-700">
            <motion.h3 
              className="text-gray-700 dark:text-gray-200 font-bold mb-4 text-right"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              آخر الأنشطة
            </motion.h3>
            <div className="border border-gray-300 dark:border-gray-600 rounded-xl p-4 bg-[#F9F9FA] dark:bg-gray-700">
              <div className="space-y-4">
                <div className="flex items-center p-3 rounded-md bg-gray-50 dark:bg-gray-600">
                  <div className="w-10 h-10 rounded-full bg-[#64C8CC] flex items-center justify-center text-white mr-3">
                    <FaUsers />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">مستخدم جديد مسجل</p>
                    <p className="text-sm text-gray-500 dark:text-gray-300">قبل 10 دقائق</p>
                  </div>
                </div>
                <div className="flex items-center p-3 rounded-md bg-gray-50 dark:bg-gray-600">
                  <div className="w-10 h-10 rounded-full bg-[#30A1DB] flex items-center justify-center text-white mr-3">
                    <FaSchool />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">مدرسة جديدة مضافة</p>
                    <p className="text-sm text-gray-500 dark:text-gray-300">قبل ساعة</p>
                  </div>
                </div>
                <div className="flex items-center p-3 rounded-md bg-gray-50 dark:bg-gray-600">
                  <div className="w-10 h-10 rounded-full bg-[#1CB654] flex items-center justify-center text-white mr-3">
                    <FaHeadset />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">طلب دعم جديد</p>
                    <p className="text-sm text-gray-500 dark:text-gray-300">قبل 3 ساعات</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>

      {/* Quick Actions */}
      <motion.div 
        className="mt-8" 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut", delay: 0.9 }}
      >
        <Card className="!bg-[#F9F9FA] dark:!bg-gray-700">
          <motion.h2 
            className="text-xl font-bold text-gray-900 dark:text-white mb-6"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 1.0 }}
          >
            الإجراءات السريعة
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, index) => (
              <motion.button
                key={action.label}
                className="p-6 rounded-xl bg-white dark:bg-gray-800 text-black dark:text-white hover:shadow-lg transition-all duration-200 flex flex-col items-center justify-center text-center group"
                whileHover={{ 
                  scale: 1.05,
                  y: -5,
                  transition: { duration: 0.3 }
                }}
                whileTap={{ scale: 0.95 }}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.6, 
                  ease: "easeOut",
                  delay: 1.1 + index * 0.1 
                }}
                onClick={action.action}
              >
                <action.icon className={`text-3xl ${action.color} mb-4 group-hover:scale-110 transition-transform self-end`} />
                <div className="text-center">
                  <p className="font-bold text-lg">{action.label}</p>
                  <p className="text-sm opacity-90 mt-1 text-gray-500 dark:text-gray-300">{action.description}</p>
                </div>
              </motion.button>
            ))}
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default Dashboard;